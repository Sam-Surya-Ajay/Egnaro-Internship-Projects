Python codes for Object detection, Distance calculation and dimension calculation 
